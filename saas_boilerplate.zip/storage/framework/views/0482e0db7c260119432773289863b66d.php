<?php $__env->startSection('title', 'Activity Logs'); ?>
<?php $__env->startSection('page-title', 'Activity Logs'); ?>

<?php $__env->startSection('content'); ?>


<form method="GET" class="flex flex-wrap gap-3 mb-6">
    <select name="user_id" onchange="this.form.submit()"
            class="text-sm border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800">
        <option value="">All members</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php echo e(request('user_id') == $u->id ? 'selected' : ''); ?>><?php echo e($u->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <input type="date" name="from" value="<?php echo e(request('from')); ?>" onchange="this.form.submit()"
           class="text-sm border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800">

    <input type="date" name="to" value="<?php echo e(request('to')); ?>" onchange="this.form.submit()"
           class="text-sm border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800">

    <?php if(request()->hasAny(['user_id', 'from', 'to'])): ?>
    <a href="/activity" class="text-sm text-primary-600 hover:underline self-center">Clear filters</a>
    <?php endif; ?>
</form>


<div class="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl">
    <div class="divide-y divide-gray-100 dark:divide-gray-800">
        <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="px-5 py-4 flex items-start gap-3">
            <img src="<?php echo e($activity->causer?->avatar_url ?? 'https://ui-avatars.com/api/?name=System'); ?>"
                 class="w-8 h-8 rounded-full flex-shrink-0 mt-0.5">
            <div class="flex-1 min-w-0">
                <p class="text-sm">
                    <span class="font-medium"><?php echo e($activity->causer?->name ?? 'System'); ?></span>
                    <?php echo e($activity->description); ?>

                </p>
                <p class="text-xs text-gray-500 mt-0.5">
                    <?php echo e($activity->created_at->format('M d, Y \a\t h:i A')); ?>

                    · <?php echo e($activity->created_at->diffForHumans()); ?>

                </p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="px-5 py-12 text-center text-sm text-gray-500">No activity logs found.</div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-4">
    <?php echo e($activities->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tenant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\saas-boilerplate\resources\views/tenant/activity/index.blade.php ENDPATH**/ ?>