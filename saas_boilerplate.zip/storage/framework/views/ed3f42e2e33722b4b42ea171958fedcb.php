<?php $__env->startSection('title', 'Team'); ?>
<?php $__env->startSection('page-title', 'Team'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ showInvite: false }">

    
    <div class="flex items-center justify-between mb-6">
        <div>
            <p class="text-sm text-gray-500 dark:text-gray-400">
                <?php echo e($currentCount); ?> of <?php echo e($limit == -1 ? 'unlimited' : $limit); ?> team members
            </p>
        </div>
        <button @click="showInvite = true"
                class="bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
            + Invite member
        </button>
    </div>

    
    <div class="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 dark:bg-gray-800/50 text-left text-xs text-gray-500 dark:text-gray-400 uppercase">
                <tr>
                    <th class="px-5 py-3 font-medium">Member</th>
                    <th class="px-5 py-3 font-medium">Role</th>
                    <th class="px-5 py-3 font-medium">Status</th>
                    <th class="px-5 py-3 font-medium">Joined</th>
                    <th class="px-5 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 dark:divide-gray-800">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-5 py-3">
                        <div class="flex items-center gap-3">
                            <img src="<?php echo e($member->avatar_url); ?>" class="w-8 h-8 rounded-full">
                            <div>
                                <p class="font-medium"><?php echo e($member->name); ?></p>
                                <p class="text-xs text-gray-500"><?php echo e($member->email); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-3">
                        <?php if($member->hasRole('owner')): ?>
                            <span class="px-2 py-0.5 rounded-full text-xs font-medium bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400">Owner</span>
                        <?php else: ?>
                            <form method="POST" action="/team/<?php echo e($member->id); ?>/role" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <select name="role" onchange="this.form.submit()"
                                        class="text-xs border border-gray-200 dark:border-gray-700 rounded-md px-2 py-1 bg-white dark:bg-gray-800">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($role->name !== 'owner'): ?>
                                        <option value="<?php echo e($role->name); ?>" <?php echo e($member->hasRole($role->name) ? 'selected' : ''); ?>>
                                            <?php echo e(ucfirst($role->name)); ?>

                                        </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-0.5 rounded-full text-xs font-medium <?php echo e($member->is_active ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'); ?>">
                            <?php echo e($member->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3 text-gray-500"><?php echo e($member->created_at->format('M d, Y')); ?></td>
                    <td class="px-5 py-3 text-right">
                        <?php if(!$member->hasRole('owner') && $member->id !== auth()->id()): ?>
                        <form method="POST" action="/team/<?php echo e($member->id); ?>"
                              onsubmit="return confirm('Remove <?php echo e($member->name); ?> from the team?')" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-xs text-red-500 hover:text-red-700">Remove</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div x-show="showInvite" x-cloak
         class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
         @click.self="showInvite = false">
        <div class="bg-white dark:bg-gray-900 rounded-xl p-6 w-full max-w-md">
            <h3 class="font-semibold mb-4">Invite team member</h3>
            <form method="POST" action="/team/invite">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Name</label>
                    <input type="text" name="name" required
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Email</label>
                    <input type="email" name="email" required
                           class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div class="mb-5">
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="role" class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($role->name !== 'owner'): ?>
                            <option value="<?php echo e($role->name); ?>"><?php echo e(ucfirst($role->name)); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex gap-2">
                    <button type="button" @click="showInvite = false"
                            class="flex-1 border border-gray-300 dark:border-gray-700 text-sm font-medium py-2 rounded-lg">
                        Cancel
                    </button>
                    <button type="submit"
                            class="flex-1 bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium py-2 rounded-lg">
                        Send invite
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tenant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\saas-boilerplate\resources\views/tenant/team/index.blade.php ENDPATH**/ ?>